package com.muzik.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.Executors

class PlayerService : Service() {
    private lateinit var session: MediaSession
    private val handler = Handler(Looper.getMainLooper())
    private val artEx = Executors.newSingleThreadExecutor()
    private var lastId = -2L
    private var lastPlaying = false
    private var lastFav = false
    private var bmp: Bitmap? = null
    private var dead = false

    override fun onBind(intent: Intent?): IBinder? = null

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY && Player.pauseOnUnplug) {
                try { Player.mp?.pause() } catch (e: Exception) {}
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (dead) return
            refresh(false)
            handler.postDelayed(this, 1500)
        }
    }

    private val cb = object : MediaSession.Callback() {
        override fun onPlay() { Player.resume(); refresh(true) }
        override fun onPause() { Player.pause(); refresh(true) }
        override fun onSkipToNext() { Player.next() }
        override fun onSkipToPrevious() { Player.prev() }
        override fun onSeekTo(pos: Long) { Player.seek(pos.toInt()); refresh(false) }
        override fun onCustomAction(action: String, extras: Bundle?) { if (action == "fav") favToggle() }
    }

    @Suppress("DEPRECATION")
    override fun onCreate() {
        super.onCreate()
        session = MediaSession(this, "Muzik")
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
        session.setCallback(cb)
        session.setSessionActivity(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        session.isActive = true
        try { registerReceiver(noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)) } catch (e: Exception) {}
        handler.postDelayed(tick, 1500)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Player.serviceUp = true
        Player.onSong = { refresh(true) }
        when (intent?.action) {
            "pp" -> Player.toggle()
            "next" -> Player.next()
            "prev" -> Player.prev()
            "fav" -> favToggle()
        }
        val id = curId()
        val playing = isPlaying()
        val fav = id >= 0 && Fav.has(this, id)
        if (id != lastId) {
            lastId = id
            bmp = null
            loadArt(id)
            updateMeta(id)
        }
        lastPlaying = playing
        lastFav = fav
        val n = buildNotification(id, playing, fav)
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)
        updateState(playing, fav)
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (Player.stopOnClear) {
            Player.stop()
            stopSelf()
        }
    }

    override fun onDestroy() {
        dead = true
        handler.removeCallbacks(tick)
        try { unregisterReceiver(noisy) } catch (e: Exception) {}
        try { session.isActive = false; session.release() } catch (e: Exception) {}
        Player.serviceUp = false
        Player.onSong = null
    }

    private fun nm(): NotificationManager = getSystemService(NotificationManager::class.java)
    private fun curId(): Long = Player.queue.getOrNull(Player.index) ?: -1L
    private fun isPlaying(): Boolean = try { Player.mp?.isPlaying == true } catch (e: Exception) { false }

    private fun favToggle() {
        val id = curId()
        if (id >= 0) {
            Fav.toggle(this, id)
            Player.onFav?.invoke()
            refresh(true)
        }
    }

    private fun refresh(force: Boolean) {
        if (dead) return
        val id = curId()
        val playing = isPlaying()
        val fav = id >= 0 && Fav.has(this, id)
        val changed = id != lastId
        if (changed) {
            lastId = id
            bmp = null
            loadArt(id)
            updateMeta(id)
        }
        updateState(playing, fav)
        if (force || changed || playing != lastPlaying || fav != lastFav) {
            lastPlaying = playing
            lastFav = fav
            try { nm().notify(1, buildNotification(id, playing, fav)) } catch (e: Exception) {}
        }
    }

    private fun loadArt(id: Long) {
        if (id < 0) return
        artEx.execute {
            val b = Art.load(applicationContext, id, 512)
            handler.post {
                if (!dead && lastId == id && b != null) {
                    bmp = b
                    updateMeta(id)
                    try { nm().notify(1, buildNotification(id, lastPlaying, lastFav)) } catch (e: Exception) {}
                }
            }
        }
    }

    private fun updateMeta(id: Long) {
        try {
            val dur = try { Player.mp?.duration?.toLong() ?: -1L } catch (e: Exception) { -1L }
            val m = MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, Player.titles[id] ?: "Muzik")
                .putString(MediaMetadata.METADATA_KEY_ARTIST, Player.artists[id] ?: "")
                .putString(MediaMetadata.METADATA_KEY_ALBUM, Player.albums[id] ?: "")
                .putLong(MediaMetadata.METADATA_KEY_DURATION, dur)
            val b = bmp
            if (b != null) m.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, b)
            session.setMetadata(m.build())
        } catch (e: Exception) {}
    }

    private fun updateState(playing: Boolean, fav: Boolean) {
        try {
            val pos = try { Player.mp?.currentPosition?.toLong() ?: 0L } catch (e: Exception) { 0L }
            val st = if (Player.queue.isEmpty()) PlaybackState.STATE_NONE
                     else if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED
            val b = PlaybackState.Builder()
                .setActions(
                    PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                        PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO
                )
                .setState(st, pos, if (playing) Player.speed else 0f, SystemClock.elapsedRealtime())
                .addCustomAction(
                    PlaybackState.CustomAction.Builder("fav", "Favorit", if (fav) R.drawable.ic_heart_on else R.drawable.ic_heart).build()
                )
            session.setPlaybackState(b.build())
        } catch (e: Exception) {}
    }

    private fun buildNotification(id: Long, playing: Boolean, fav: Boolean): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            nm().createNotificationChannel(NotificationChannel("play", "Pemain muzik", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        fun act(a: String, code: Int): PendingIntent = PendingIntent.getService(
            this, code, Intent(this, PlayerService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        fun ac(icon: Int, label: String, pi: PendingIntent): Notification.Action =
            Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi).build()
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "play") else Notification.Builder(this)
        b.setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(Player.titles[id] ?: "Muzik")
            .setContentText(Player.artists[id] ?: "")
            .setContentIntent(open)
            .setOngoing(true)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(ac(R.drawable.ic_menu, "Buka", open))
            .addAction(ac(R.drawable.ic_prev, "Sebelumnya", act("prev", 1)))
            .addAction(ac(if (playing) R.drawable.ic_pause else R.drawable.ic_play, if (playing) "Jeda" else "Main", act("pp", 2)))
            .addAction(ac(R.drawable.ic_next, "Seterusnya", act("next", 3)))
            .addAction(ac(if (fav) R.drawable.ic_heart_on else R.drawable.ic_heart, "Favorit", act("fav", 4)))
            .setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(1, 2, 3))
        val l = bmp
        if (l != null) b.setLargeIcon(l)
        return b.build()
    }
}
