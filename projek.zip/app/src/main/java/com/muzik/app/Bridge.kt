package com.muzik.app

import android.content.ContentUris
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import android.util.Base64
import android.util.Size
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

class Bridge(private val a: MainActivity) {
    private val h = Handler(Looper.getMainLooper())

    @JavascriptInterface fun hasPerm(): Boolean = a.hasAudioPerm()
    @JavascriptInterface fun askPerm() { h.post { a.askPerms() } }

    @JavascriptInterface fun version(): String {
        val i = a.packageManager.getPackageInfo(a.packageName, 0)
        @Suppress("DEPRECATION") val c = i.versionCode
        return "${i.versionName}|${c % 1000}"
    }

    private fun dirOf(p: String?): String {
        if (p.isNullOrEmpty()) return ""
        return if (Build.VERSION.SDK_INT >= 29) p.trimEnd('/') else (java.io.File(p).parent ?: "")
    }

    @JavascriptInterface fun songs(): String {
        if (!a.hasAudioPerm()) return "[]"
        val list = ArrayList<JSONObject>()
        val sel = "${MediaStore.Audio.Media.IS_MUSIC}!=0"
        a.contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATE_ADDED, if (Build.VERSION.SDK_INT >= 29) MediaStore.MediaColumns.RELATIVE_PATH else MediaStore.Audio.Media.DATA), sel, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val t = c.getString(1) ?: "Tanpa tajuk"
                var ar = c.getString(2) ?: ""
                if (ar.isEmpty() || ar == "<unknown>") ar = "Artis tidak diketahui"
                Player.titles[id] = t
                list.add(JSONObject().put("id", id).put("title", t).put("artist", ar).put("dur", c.getLong(3)).put("added", c.getLong(4)).put("dir", dirOf(c.getString(5))))
            }
        }
        list.sortBy { it.getString("title").lowercase() }
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        return arr.toString()
    }

    @JavascriptInterface fun plays(): String = Player.playsJson()
    @JavascriptInterface fun getData(): String = a.getSharedPreferences("muzik", 0).getString("data", "{}") ?: "{}"
    @JavascriptInterface fun setData(s: String) { a.getSharedPreferences("muzik", 0).edit().putString("data", s).apply() }

    @JavascriptInterface fun info(id: Long): String {
        val o = JSONObject()
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
        val proj = arrayOf(
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.YEAR, MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DURATION
        )
        try {
            val c = a.contentResolver.query(uri, proj, null, null, null)
            try {
                if (c != null && c.moveToFirst()) {
                    o.put("album", c.getString(0) ?: "")
                    o.put("size", c.getLong(1))
                    o.put("mime", c.getString(2) ?: "")
                    o.put("file", c.getString(3) ?: "")
                    o.put("year", c.getInt(4))
                    o.put("path", c.getString(5) ?: "")
                    o.put("dur", c.getLong(6))
                }
            } finally { c?.close() }
        } catch (e: Exception) {}
        try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(a, uri)
                o.put("bitrate", r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE) ?: "")
            } finally { r.release() }
        } catch (e: Exception) {}
        o.put("plays", Player.playsOf(id))
        return o.toString()
    }

    private val ex = Executors.newSingleThreadExecutor()
    private val artCache = HashMap<Long, String>()

    @JavascriptInterface fun loadArt(id: Long) {
        ex.execute {
            val d = artCache.getOrPut(id) { makeArt(id) }
            a.runOnUiThread { a.web.evaluateJavascript("window.onArt&&window.onArt($id,'$d')", null) }
        }
    }

    private fun makeArt(id: Long): String {
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
        var bmp: Bitmap? = null
        try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(a, uri)
                val b = r.embeddedPicture
                if (b != null) {
                    val o = BitmapFactory.Options()
                    o.inJustDecodeBounds = true
                    BitmapFactory.decodeByteArray(b, 0, b.size, o)
                    var ss = 1
                    while (o.outWidth / ss > 700) ss *= 2
                    val o2 = BitmapFactory.Options()
                    o2.inSampleSize = ss
                    bmp = BitmapFactory.decodeByteArray(b, 0, b.size, o2)
                }
            } finally { r.release() }
        } catch (e: Exception) {}
        if (bmp == null && Build.VERSION.SDK_INT >= 29) {
            try { bmp = a.contentResolver.loadThumbnail(uri, Size(360, 360), null) } catch (e: Exception) {}
        }
        val src = bmp ?: return ""
        val side = minOf(src.width, src.height)
        var sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        if (side > 360) sq = Bitmap.createScaledBitmap(sq, 360, 360, true)
        val out = ByteArrayOutputStream()
        sq.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    @JavascriptInterface fun playQueue(ids: String, index: Int) {
        val j = JSONArray(ids)
        val l = List(j.length()) { j.getLong(it) }
        h.post { Player.play(l, index) }
    }
    @JavascriptInterface fun setVol(v: Double) { h.post { Player.setVolume(v) } }
    @JavascriptInterface fun setSpeed(v: Double) { h.post { Player.setSpeed(v.toFloat()) } }
    @JavascriptInterface fun setSleep(min: Int) { h.post { Player.setSleep(min) } }
    @JavascriptInterface fun playNext(id: Long) { h.post { Player.playNext(id) } }
    @JavascriptInterface fun addQueue(id: Long) { h.post { Player.addToQueue(id) } }

    @JavascriptInterface fun share(id: Long) {
        h.post {
            try {
                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                val i = Intent(Intent.ACTION_SEND)
                i.type = "audio/*"
                i.putExtra(Intent.EXTRA_STREAM, uri)
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                a.startActivity(Intent.createChooser(i, "Kongsi lagu"))
            } catch (e: Exception) {}
        }
    }

    @JavascriptInterface fun openOutput() {
        h.post {
            try {
                if (Build.VERSION.SDK_INT >= 29) a.startActivity(Intent(android.provider.Settings.Panel.ACTION_VOLUME))
                else a.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
            } catch (e: Exception) {}
        }
    }

    @JavascriptInterface fun toggle() { h.post { Player.toggle() } }
    @JavascriptInterface fun next() { h.post { Player.next() } }
    @JavascriptInterface fun prev() { h.post { Player.prev() } }
    @JavascriptInterface fun seek(ms: Int) { h.post { Player.seek(ms) } }
    @JavascriptInterface fun setShuffle(b: Boolean) { Player.shuffle = b }
    @JavascriptInterface fun setRepeat(n: Int) { Player.repeat = n }
    @JavascriptInterface fun state(): String = Player.state()
}
