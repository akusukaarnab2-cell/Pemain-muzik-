package com.muzik.app

import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject

class Bridge(private val a: MainActivity) {
    private val h = Handler(Looper.getMainLooper())

    @JavascriptInterface fun hasPerm(): Boolean = a.hasAudioPerm()
    @JavascriptInterface fun askPerm() { h.post { a.askPerms() } }

    @JavascriptInterface fun version(): String {
        val i = a.packageManager.getPackageInfo(a.packageName, 0)
        @Suppress("DEPRECATION") val c = i.versionCode
        return "${i.versionName}|${c % 1000}"
    }

    @JavascriptInterface fun songs(): String {
        if (!a.hasAudioPerm()) return "[]"
        val list = ArrayList<JSONObject>()
        val sel = "${MediaStore.Audio.Media.IS_MUSIC}!=0 AND ${MediaStore.Audio.Media.DURATION}>30000"
        a.contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION), sel, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val t = c.getString(1) ?: "Tanpa tajuk"
                var ar = c.getString(2) ?: ""
                if (ar.isEmpty() || ar == "<unknown>") ar = "Artis tidak diketahui"
                Player.titles[id] = t
                list.add(JSONObject().put("id", id).put("title", t).put("artist", ar).put("dur", c.getLong(3)))
            }
        }
        list.sortBy { it.getString("title").lowercase() }
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        return arr.toString()
    }

    @JavascriptInterface fun playQueue(ids: String, index: Int) {
        val j = JSONArray(ids)
        val l = List(j.length()) { j.getLong(it) }
        h.post { Player.play(l, index) }
    }
    @JavascriptInterface fun toggle() { h.post { Player.toggle() } }
    @JavascriptInterface fun next() { h.post { Player.next() } }
    @JavascriptInterface fun prev() { h.post { Player.prev() } }
    @JavascriptInterface fun seek(ms: Int) { h.post { Player.seek(ms) } }
    @JavascriptInterface fun setShuffle(b: Boolean) { Player.shuffle = b }
    @JavascriptInterface fun setRepeat(n: Int) { Player.repeat = n }
    @JavascriptInterface fun state(): String = Player.state()
}
