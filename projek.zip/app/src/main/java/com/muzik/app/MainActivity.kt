package com.muzik.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import org.json.JSONObject

class MainActivity : Activity() {
    lateinit var web: WebView

    fun hasAudioPerm(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    }

    fun askPerms() {
        val p = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            p.add(Manifest.permission.READ_MEDIA_AUDIO)
            p.add(Manifest.permission.POST_NOTIFICATIONS)
        } else p.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        val need = p.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    fun isDarkSys(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    fun applyColors(top: Int, bottom: Int) {
        window.statusBarColor = top
        window.navigationBarColor = bottom
        window.decorView.systemUiVisibility = 0
        if (::web.isInitialized) web.setBackgroundColor(bottom)
    }

    fun applyBars(dark: Boolean) {
        val c = if (dark) Color.BLACK else Color.WHITE
        window.statusBarColor = c
        window.navigationBarColor = c
        var f = if (dark) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (!dark && Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = f
        if (::web.isInitialized) web.setBackgroundColor(c)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        web.evaluateJavascript("window.sysTheme&&window.sysTheme()", null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Player.app = applicationContext
        web = WebView(this)
        val th = try {
            JSONObject(getSharedPreferences("muzik", 0).getString("data", "{}") ?: "{}").optString("theme", "light")
        } catch (e: Exception) { "light" }
        applyBars(th == "dark" || (th == "auto" && isDarkSys()))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(this), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        askPerms()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        web.evaluateJavascript("window.reload&&window.reload()", null)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript("window.onBack?window.onBack():'exit'") { r ->
            if (r == null || r.contains("exit")) moveTaskToBack(true)
        }
    }
}
