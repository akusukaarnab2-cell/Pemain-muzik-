package com.muzik.app

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.provider.MediaStore
import android.util.Size

object Art {
    fun load(ctx: Context, id: Long, max: Int): Bitmap? {
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
        var bmp: Bitmap? = null
        try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                val b = r.embeddedPicture
                if (b != null) {
                    val o = BitmapFactory.Options()
                    o.inJustDecodeBounds = true
                    BitmapFactory.decodeByteArray(b, 0, b.size, o)
                    var ss = 1
                    while (o.outWidth / ss > max * 2) ss *= 2
                    val o2 = BitmapFactory.Options()
                    o2.inSampleSize = ss
                    bmp = BitmapFactory.decodeByteArray(b, 0, b.size, o2)
                }
            } finally { r.release() }
        } catch (e: Exception) {}
        if (bmp == null && Build.VERSION.SDK_INT >= 29) {
            try { bmp = ctx.contentResolver.loadThumbnail(uri, Size(max, max), null) } catch (e: Exception) {}
        }
        val src = bmp ?: return null
        val side = minOf(src.width, src.height)
        var sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        if (side > max) sq = Bitmap.createScaledBitmap(sq, max, max, true)
        return sq
    }
}
