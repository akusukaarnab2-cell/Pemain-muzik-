package com.muzik.app

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.PowerManager
import android.provider.MediaStore
import org.json.JSONObject

object Player {
    lateinit var app: Context
    val titles = HashMap<Long, String>()
    @Volatile var mp: MediaPlayer? = null
    var queue: List<Long> = emptyList()
    var index = -1
    var shuffle = false
    var repeat = 0 // 0 mati, 1 semua, 2 satu lagu
    var serviceUp = false
    var onSong: (() -> Unit)? = null

    private val focus = AudioManager.OnAudioFocusChangeListener { c ->
        if (c == AudioManager.AUDIOFOCUS_LOSS || c == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            try { mp?.pause() } catch (e: Exception) {}
        }
    }

    fun title(): String = titles[queue.getOrNull(index)] ?: "Muzik"

    fun play(ids: List<Long>, i: Int) { queue = ids; index = i; start() }

    private fun start() {
        val id = queue.getOrNull(index) ?: return
        try { mp?.release() } catch (e: Exception) {}
        mp = null
        try {
            val m = MediaPlayer()
            m.setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
            m.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            m.setDataSource(app, ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id))
            m.setOnCompletionListener { ended() }
            m.setOnErrorListener { _, _, _ -> true }
            m.prepare()
            @Suppress("DEPRECATION")
            (app.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                .requestAudioFocus(focus, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
            m.start()
            mp = m
        } catch (e: Exception) { return }
        if (serviceUp) {
            onSong?.invoke()
        } else {
            try {
                val i = Intent(app, PlayerService::class.java)
                if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i) else app.startService(i)
            } catch (e: Exception) {}
        }
    }

    private fun ended() {
        if (repeat == 2) { mp?.seekTo(0); mp?.start() }
        else if (repeat == 0 && !shuffle && index == queue.lastIndex) { /* habis */ }
        else next()
    }

    fun next() {
        if (queue.isEmpty()) return
        if (shuffle && queue.size > 1) {
            var n = index
            while (n == index) n = (Math.random() * queue.size).toInt()
            index = n
        } else index = (index + 1) % queue.size
        start()
    }

    fun prev() {
        if (queue.isEmpty()) return
        val p = try { mp?.currentPosition ?: 0 } catch (e: Exception) { 0 }
        if (p > 3000) { mp?.seekTo(0); return }
        index = (index - 1 + queue.size) % queue.size
        start()
    }

    fun toggle() {
        try { mp?.let { if (it.isPlaying) it.pause() else it.start() } } catch (e: Exception) {}
    }

    fun seek(ms: Int) { try { mp?.seekTo(ms) } catch (e: Exception) {} }

    fun stop() {
        try { mp?.release() } catch (e: Exception) {}
        mp = null; queue = emptyList(); index = -1
    }

    fun state(): String {
        var pl = false; var pos = 0; var dur = 0
        try { mp?.let { pl = it.isPlaying; pos = it.currentPosition; dur = it.duration } } catch (e: Exception) {}
        val id = queue.getOrNull(index) ?: -1L
        return JSONObject().put("id", id).put("playing", pl).put("pos", pos).put("dur", dur)
            .put("shuffle", shuffle).put("rep", repeat).toString()
    }
}
