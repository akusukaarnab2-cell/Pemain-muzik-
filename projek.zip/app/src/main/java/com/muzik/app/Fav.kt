package com.muzik.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Fav {
    private fun load(ctx: Context): JSONObject =
        try { JSONObject(ctx.getSharedPreferences("muzik", 0).getString("data", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun ids(o: JSONObject): ArrayList<Long> {
        val l = ArrayList<Long>()
        val a = o.optJSONArray("fav") ?: JSONArray()
        for (i in 0 until a.length()) l.add(a.getLong(i))
        return l
    }

    fun has(ctx: Context, id: Long): Boolean = ids(load(ctx)).contains(id)

    fun toggle(ctx: Context, id: Long): Boolean {
        val o = load(ctx)
        val l = ids(o)
        val now = if (l.contains(id)) { l.remove(id); false } else { l.add(id); true }
        val a = JSONArray()
        for (x in l) a.put(x)
        o.put("fav", a)
        ctx.getSharedPreferences("muzik", 0).edit().putString("data", o.toString()).apply()
        return now
    }
}
