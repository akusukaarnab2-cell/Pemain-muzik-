package com.muzik.app

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

object Lyrics {
    private class R(val src: String, val lrc: String, val synced: Boolean, val ldur: Int)

    private val ex = Executors.newFixedThreadPool(2)
    private val miss = HashSet<Long>()
    private val stamp = Regex("\\[\\d+:\\d+(\\.\\d+)?]")
    @Volatile private var mxToken: String? = null

    private fun q(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun get(u: String, ref: String? = null, hdr: Map<String, String>? = null): String? {
        return try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 7000
            c.setRequestProperty("User-Agent", "Muzik/2.9 (Android)")
            if (ref != null) c.setRequestProperty("Referer", ref)
            if (hdr != null) for ((k, v) in hdr) c.setRequestProperty(k, v)
            val s = if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
            c.disconnect()
            s
        } catch (e: Exception) { null }
    }

    private fun firstArtist(a: String): String =
        a.split(Regex(",|&| feat\\.? | ft\\.? | x ", RegexOption.IGNORE_CASE))[0].trim()

    private fun cleanTitle(t: String): String = t.replace(Regex("\\s*[(\\[].*?[)\\]]"), "").trim()

    private fun known(a: String): Boolean = a.isNotEmpty() && a != "Artis tidak diketahui"

    // ---------- LRCLIB ----------
    private fun lrclib(title: String, artist: String, album: String, dur: Int): R? {
        val ar = firstArtist(artist)
        val kn = known(ar)
        var o: JSONObject? = null
        if (kn) {
            var url = "https://lrclib.net/api/get?track_name=${q(title)}&artist_name=${q(ar)}"
            if (album.isNotEmpty()) url += "&album_name=${q(album)}"
            if (dur > 0) url += "&duration=$dur"
            o = try { get(url)?.let { JSONObject(it) } } catch (e: Exception) { null }
            if (o != null && dur > 0) {
                val ld = o.optDouble("duration", 0.0).toInt()
                if (ld > 0 && Math.abs(ld - dur) > 4) o = null
            }
        }
        if (o == null || (o.isNull("syncedLyrics") && o.isNull("plainLyrics"))) {
            val kw = if (kn) "${cleanTitle(title)} $ar" else cleanTitle(title)
            val arr = try { get("https://lrclib.net/api/search?q=${q(kw)}")?.let { JSONArray(it) } } catch (e: Exception) { null }
            o = null
            if (arr != null) {
                var bestD = Int.MAX_VALUE
                for (i in 0 until arr.length()) {
                    val c = arr.getJSONObject(i)
                    val hasSync = !c.isNull("syncedLyrics") && c.getString("syncedLyrics").isNotBlank()
                    if (!hasSync) continue
                    val d = if (dur > 0) Math.abs(c.optDouble("duration", 0.0).toInt() - dur) else 0
                    if (d < bestD) { bestD = d; o = c }
                }
                if (o != null && dur > 0 && bestD > 4) o = null
            }
        }
        val c = o ?: return null
        val ld = c.optDouble("duration", 0.0).toInt()
        val sy = if (c.isNull("syncedLyrics")) "" else c.getString("syncedLyrics")
        if (sy.isNotBlank()) return R("LRCLIB", sy, true, ld)
        val pl = if (c.isNull("plainLyrics")) "" else c.getString("plainLyrics")
        return if (pl.isNotBlank()) R("LRCLIB", pl, false, ld) else null
    }

    // ---------- NetEase ----------
    private fun netease(title: String, artist: String, dur: Int): R? {
        val ar = firstArtist(artist)
        val kw = q((cleanTitle(title) + " " + (if (known(ar)) ar else "")).trim())
        val ref = "https://music.163.com"
        val s = get("https://music.163.com/api/search/get/web?s=$kw&type=1&offset=0&limit=5", ref) ?: return null
        val songs = JSONObject(s).optJSONObject("result")?.optJSONArray("songs") ?: return null
        var best = -1L
        var bd = Int.MAX_VALUE
        var bdur = 0
        for (i in 0 until songs.length()) {
            val o = songs.getJSONObject(i)
            val dd = o.optInt("duration", 0) / 1000
            val d = if (dd == 0 || dur <= 0) 0 else Math.abs(dd - dur)
            if (d < bd) { bd = d; best = o.getLong("id"); bdur = dd }
        }
        if (best < 0 || bd > 5) return null
        val l = get("https://music.163.com/api/song/lyric?id=$best&lv=-1&tv=-1", ref) ?: return null
        val lrc = JSONObject(l).optJSONObject("lrc")?.optString("lyric", "") ?: ""
        if (lrc.isBlank()) return null
        return R("NetEase Music", lrc, stamp.containsMatchIn(lrc), bdur)
    }

    // ---------- KuGou ----------
    private fun kugou(title: String, artist: String, dur: Int): R? {
        val ar = firstArtist(artist)
        val kw = q(if (known(ar)) "$ar - ${cleanTitle(title)}" else cleanTitle(title))
        val s = get("https://lyrics.kugou.com/search?ver=1&man=yes&client=pc&keyword=$kw&duration=${dur * 1000}&hash=") ?: return null
        val cands = JSONObject(s).optJSONArray("candidates") ?: return null
        if (cands.length() == 0) return null
        var bi = 0
        var bdiff = Int.MAX_VALUE
        var bdur = 0
        for (i in 0 until cands.length()) {
            val c = cands.getJSONObject(i)
            val cd = c.optInt("duration", 0) / 1000
            val diff = if (cd == 0 || dur <= 0) 0 else Math.abs(cd - dur)
            if (diff < bdiff) { bdiff = diff; bi = i; bdur = cd }
        }
        if (bdiff > 6) return null
        val o = cands.getJSONObject(bi)
        val d = get("https://lyrics.kugou.com/download?ver=1&client=pc&id=${o.getString("id")}&accesskey=${o.getString("accesskey")}&fmt=lrc&charset=utf8") ?: return null
        val content = JSONObject(d).optString("content", "")
        if (content.isEmpty()) return null
        val lrc = String(Base64.decode(content, Base64.DEFAULT), Charsets.UTF_8).replace("\uFEFF", "")
        if (lrc.isBlank()) return null
        return R("KuGou", lrc, stamp.containsMatchIn(lrc), bdur)
    }

    // ---------- Musixmatch (token + search + richsync/subtitle) ----------
    private fun mxFetchToken(): String? {
        val guid = UUID.randomUUID().toString().replace("-", "").take(16)
        val s = get(
            "https://apic.musixmatch.com/ws/1.1/token.get?app_id=web-desktop-app-v1.0&guid=$guid&format=json&t=${System.currentTimeMillis()}",
            null, mapOf("Cookie" to "AWSELB=0; AWSELBCORS=0")
        ) ?: return null
        val t = try { JSONObject(s).optJSONObject("message")?.optJSONObject("body")?.optString("user_token", "") ?: "" } catch (e: Exception) { "" }
        if (t.isBlank() || t.startsWith("Upgrade")) return null
        mxToken = t
        return t
    }

    private fun mxCall(path: String, params: String, tok: String): JSONObject? {
        val u = "https://apic.musixmatch.com/ws/1.1/$path?app_id=web-desktop-app-v1.0&format=json&usertoken=${q(tok)}&t=${System.currentTimeMillis()}&$params"
        val s = get(u, null, mapOf("Cookie" to "AWSELB=0; AWSELBCORS=0")) ?: return null
        return try { JSONObject(s) } catch (e: Exception) { null }
    }

    private fun mxGet(path: String, params: String): JSONObject? {
        var tok = mxToken ?: mxFetchToken() ?: return null
        var o = mxCall(path, params, tok)
        val code = o?.optJSONObject("message")?.optJSONObject("header")?.optInt("status_code", 200) ?: 0
        if (o == null || code == 401) {
            mxToken = null
            tok = mxFetchToken() ?: return null
            o = mxCall(path, params, tok)
        }
        return o
    }

    private fun tsStr(sec: Double): String {
        val ms = Math.round(sec * 100)
        val m = ms / 6000
        val s = (ms % 6000) / 100.0
        return String.format(Locale.US, "%02d:%05.2f", m, s)
    }

    private fun richToLrc(body: String): String {
        if (body.isBlank()) return ""
        return try {
            val a = JSONArray(body)
            val sb = StringBuilder()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val t0 = o.optDouble("ts", 0.0)
                val l = o.optJSONArray("l") ?: continue
                val ts = ArrayList<Double>()
                val tx = ArrayList<String>()
                for (j in 0 until l.length()) {
                    val w = l.getJSONObject(j)
                    var c = w.optString("c", "")
                    if (tx.isNotEmpty()) {
                        val lead = c.length - c.trimStart().length
                        if (lead > 0) { tx[tx.size - 1] = tx[tx.size - 1] + c.substring(0, lead); c = c.substring(lead) }
                        if (c.isEmpty()) continue
                    } else if (c.isBlank()) continue
                    ts.add(t0 + w.optDouble("o", 0.0))
                    tx.add(c)
                }
                if (tx.isEmpty()) continue
                sb.append('[').append(tsStr(t0)).append(']')
                for (j in tx.indices) sb.append('<').append(tsStr(ts[j])).append('>').append(tx[j])
                sb.append('\n')
                val te = o.optDouble("te", -1.0)
                if (te > 0 && i + 1 < a.length()) {
                    val nt = a.getJSONObject(i + 1).optDouble("ts", 0.0)
                    if (nt - te > 3) sb.append('[').append(tsStr(te)).append("]\n")
                }
            }
            sb.toString()
        } catch (e: Exception) { "" }
    }

    private fun musixmatch(title: String, artist: String, dur: Int): R? {
        val ar = firstArtist(artist)
        val params = "q_track=${q(cleanTitle(title))}" + (if (known(ar)) "&q_artist=${q(ar)}" else "") +
            "&page_size=5&page=1&s_track_rating=desc&f_has_lyrics=1"
        val sr = mxGet("track.search", params) ?: return null
        val list = sr.optJSONObject("message")?.optJSONObject("body")?.optJSONArray("track_list") ?: return null
        var best: JSONObject? = null
        var bd = Int.MAX_VALUE
        for (i in 0 until list.length()) {
            val t = list.getJSONObject(i).optJSONObject("track") ?: continue
            val l = t.optInt("track_length", 0)
            val d = if (l == 0 || dur <= 0) 0 else Math.abs(l - dur)
            if (d < bd) { bd = d; best = t }
        }
        val tr = best ?: return null
        if (bd > 5) return null
        val tid = tr.optLong("track_id")
        val cid = tr.optLong("commontrack_id")
        val len = tr.optInt("track_length", 0)
        if (tr.optInt("has_richsync", 0) == 1) {
            val rs = mxGet("track.richsync.get", "track_id=$tid&commontrack_id=$cid&f_richsync_length=$len")
            val body = rs?.optJSONObject("message")?.optJSONObject("body")?.optJSONObject("richsync")?.optString("richsync_body", "") ?: ""
            val lrc = richToLrc(body)
            if (lrc.isNotBlank()) return R("Musixmatch", lrc, true, len)
        }
        if (tr.optInt("has_subtitles", 0) == 1) {
            val sb = mxGet("track.subtitle.get", "track_id=$tid&commontrack_id=$cid&subtitle_format=lrc&f_subtitle_length=$len")
            val lrc = sb?.optJSONObject("message")?.optJSONObject("body")?.optJSONObject("subtitle")?.optString("subtitle_body", "") ?: ""
            if (lrc.isNotBlank() && stamp.containsMatchIn(lrc)) return R("Musixmatch", lrc, true, len)
        }
        return null
    }

    // ---------- generic JSON scanner (LRC.red, SimpMusic, Unison) ----------
    private fun scan(n: Any?, out: ArrayList<Pair<String, Int>>) {
        when (n) {
            is JSONObject -> {
                var d = 0
                for (k in listOf("duration", "durationSeconds", "length", "track_length")) {
                    if (n.has(k)) {
                        val v = n.optDouble(k, 0.0)
                        d = if (v > 10000) (v / 1000).toInt() else v.toInt()
                        break
                    }
                }
                val it = n.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    val v = n.opt(k)
                    if (v is String) {
                        if (stamp.findAll(v).count() >= 4) out.add(Pair(v, d))
                    } else scan(v, out)
                }
            }
            is JSONArray -> for (i in 0 until n.length()) scan(n.opt(i), out)
        }
    }

    private fun findLrc(s: String, name: String, dur: Int): R? {
        val root: Any? = try { if (s.trim().startsWith("[")) JSONArray(s) else JSONObject(s) } catch (e: Exception) { null }
        val out = ArrayList<Pair<String, Int>>()
        if (root != null) scan(root, out) else if (stamp.findAll(s).count() >= 4) out.add(Pair(s, 0))
        var best: Pair<String, Int>? = null
        var bd = Int.MAX_VALUE
        for (p in out) {
            val d = if (p.second == 0 || dur <= 0) 0 else Math.abs(p.second - dur)
            if (d < bd) { bd = d; best = p }
        }
        val b = best ?: return null
        if (bd > 5) return null
        return R(name, b.first.replace("\uFEFF", ""), true, b.second)
    }

    private fun lrcred(title: String, artist: String, album: String, dur: Int): R? {
        val ar = firstArtist(artist)
        val kw = (cleanTitle(title) + " " + (if (known(ar)) ar else "")).trim()
        val u = "https://lrc.red/search.json?q=${q(kw)}&query=${q(kw)}&track_name=${q(title)}&artist_name=${q(if (known(ar)) ar else "")}" +
            "&album_name=${q(album)}&duration=$dur"
        val s = get(u) ?: return null
        return findLrc(s, "LRC.red", dur)
    }

    private fun simpmusic(title: String, artist: String, dur: Int): R? {
        val ar = firstArtist(artist)
        val kw = (cleanTitle(title) + " " + (if (known(ar)) ar else "")).trim()
        val s = get("https://api-lyrics.simpmusic.org/v1/search?q=${q(kw)}")
            ?: get("https://api-lyrics.simpmusic.org/v1/search/title?title=${q(cleanTitle(title))}")
            ?: return null
        return findLrc(s, "SimpMusic", dur)
    }

    private fun unison(title: String, artist: String, album: String, dur: Int): R? {
        val ar = firstArtist(artist)
        val u = "https://unison.boidu.dev/lyrics?song=${q(cleanTitle(title))}&artist=${q(if (known(ar)) ar else "")}" +
            "&album=${q(album)}&duration=$dur"
        val s = get(u) ?: return null
        return findLrc(s, "Unison", dur)
    }

    private fun res(id: Long, r: R?): JSONObject =
        JSONObject().put("id", id).put("src", r?.src ?: "").put("synced", r?.synced ?: false)
            .put("lrc", r?.lrc ?: "").put("ldur", r?.ldur ?: 0)

    fun fetch(ctx: Context, id: Long, title: String, artist: String, album: String, dur: Int,
              order: String, force: Boolean, cb: (String) -> Unit) {
        ex.execute {
            val dir = File(ctx.filesDir, "lyrics")
            dir.mkdirs()
            val f = File(dir, "$id.json")
            if (!force && f.exists()) {
                try { cb(f.readText()); return@execute } catch (e: Exception) {}
            }
            if (force) synchronized(miss) { miss.remove(id) }
            val skip = synchronized(miss) { miss.contains(id) }
            if (order.isBlank() || skip) { cb(res(id, null).toString()); return@execute }
            var plain: R? = null
            var hit: R? = null
            for (s in order.split(",")) {
                val r: R? = try {
                    when (s) {
                        "lrclib" -> lrclib(title, artist, album, dur)
                        "netease" -> netease(title, artist, dur)
                        "kugou" -> kugou(title, artist, dur)
                        "musixmatch" -> musixmatch(title, artist, dur)
                        "lrcred" -> lrcred(title, artist, album, dur)
                        "simpmusic" -> simpmusic(title, artist, dur)
                        "unison" -> unison(title, artist, album, dur)
                        else -> null
                    }
                } catch (e: Exception) { null }
                if (r == null) continue
                if (r.synced) { hit = r; break }
                if (plain == null) plain = r
            }
            val fin = hit ?: plain
            val j = res(id, fin).toString()
            if (fin != null) {
                try { f.writeText(j) } catch (e: Exception) {}
            } else synchronized(miss) { miss.add(id) }
            cb(j)
        }
    }

    fun clear(ctx: Context) {
        try { File(ctx.filesDir, "lyrics").listFiles()?.forEach { it.delete() } } catch (e: Exception) {}
        synchronized(miss) { miss.clear() }
    }
}
