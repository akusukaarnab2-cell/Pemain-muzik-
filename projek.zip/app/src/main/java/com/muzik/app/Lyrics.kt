package com.muzik.app

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

object Lyrics {
    private class R(val src: String, val lrc: String, val synced: Boolean, val ldur: Int)

    private val ex = Executors.newFixedThreadPool(2)
    private val miss = HashSet<Long>()
    private val stamp = Regex("\\[\\d+:\\d+(\\.\\d+)?]")

    private fun q(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun get(u: String, ref: String? = null): String? {
        return try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Muzik/2.5 (Android)")
            if (ref != null) c.setRequestProperty("Referer", ref)
            val s = if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
            c.disconnect()
            s
        } catch (e: Exception) { null }
    }

    private fun firstArtist(a: String): String =
        a.split(Regex(",|&| feat\\.? | ft\\.? | x ", RegexOption.IGNORE_CASE))[0].trim()

    private fun cleanTitle(t: String): String = t.replace(Regex("\\s*[(\\[].*?[)\\]]"), "").trim()

    private fun known(a: String): Boolean = a.isNotEmpty() && a != "Artis tidak diketahui"

    private fun lrclib(title: String, artist: String, album: String, dur: Int): R? {
        val ar = firstArtist(artist)
        val kn = known(ar)
        var o: JSONObject? = null
        if (kn) {
            var url = "https://lrclib.net/api/get?track_name=${q(title)}&artist_name=${q(ar)}"
            if (album.isNotEmpty()) url += "&album_name=${q(album)}"
            if (dur > 0) url += "&duration=$dur"
            o = try { get(url)?.let { JSONObject(it) } } catch (e: Exception) { null }
            if (o != null && dur > 0) {
                val ld = o.optDouble("duration", 0.0).toInt()
                if (ld > 0 && Math.abs(ld - dur) > 4) o = null
            }
        }
        if (o == null || (o.isNull("syncedLyrics") && o.isNull("plainLyrics"))) {
            val kw = if (kn) "${cleanTitle(title)} $ar" else cleanTitle(title)
            val arr = try { get("https://lrclib.net/api/search?q=${q(kw)}")?.let { JSONArray(it) } } catch (e: Exception) { null }
            o = null
            if (arr != null) {
                var bestD = Int.MAX_VALUE
                for (i in 0 until arr.length()) {
                    val c = arr.getJSONObject(i)
                    val hasSync = !c.isNull("syncedLyrics") && c.getString("syncedLyrics").isNotBlank()
                    if (!hasSync) continue
                    val d = if (dur > 0) Math.abs(c.optDouble("duration", 0.0).toInt() - dur) else 0
                    if (d < bestD) { bestD = d; o = c }
                }
                if (o != null && dur > 0 && bestD > 4) o = null
            }
        }
        val c = o ?: return null
        val ld = c.optDouble("duration", 0.0).toInt()
        val sy = if (c.isNull("syncedLyrics")) "" else c.getString("syncedLyrics")
        if (sy.isNotBlank()) return R("LRCLIB", sy, true, ld)
        val pl = if (c.isNull("plainLyrics")) "" else c.getString("plainLyrics")
        return if (pl.isNotBlank()) R("LRCLIB", pl, false, ld) else null
    }

    private fun netease(title: String, artist: String, dur: Int): R? {
        val ar = firstArtist(artist)
        val kw = q((cleanTitle(title) + " " + (if (known(ar)) ar else "")).trim())
        val ref = "https://music.163.com"
        val s = get("https://music.163.com/api/search/get/web?s=$kw&type=1&offset=0&limit=5", ref) ?: return null
        val songs = JSONObject(s).optJSONObject("result")?.optJSONArray("songs") ?: return null
        var best = -1L
        var bd = Int.MAX_VALUE
        var bdur = 0
        for (i in 0 until songs.length()) {
            val o = songs.getJSONObject(i)
            val dd = o.optInt("duration", 0) / 1000
            val d = if (dd == 0 || dur <= 0) 0 else Math.abs(dd - dur)
            if (d < bd) { bd = d; best = o.getLong("id"); bdur = dd }
        }
        if (best < 0 || bd > 5) return null
        val l = get("https://music.163.com/api/song/lyric?id=$best&lv=-1&tv=-1", ref) ?: return null
        val lrc = JSONObject(l).optJSONObject("lrc")?.optString("lyric", "") ?: ""
        if (lrc.isBlank()) return null
        return R("NetEase Music", lrc, stamp.containsMatchIn(lrc), bdur)
    }

    private fun kugou(title: String, artist: String, dur: Int): R? {
        val ar = firstArtist(artist)
        val kw = q(if (known(ar)) "$ar - ${cleanTitle(title)}" else cleanTitle(title))
        val s = get("https://lyrics.kugou.com/search?ver=1&man=yes&client=pc&keyword=$kw&duration=${dur * 1000}&hash=") ?: return null
        val cands = JSONObject(s).optJSONArray("candidates") ?: return null
        if (cands.length() == 0) return null
        var bi = 0
        var bdiff = Int.MAX_VALUE
        var bdur = 0
        for (i in 0 until cands.length()) {
            val c = cands.getJSONObject(i)
            val cd = c.optInt("duration", 0) / 1000
            val diff = if (cd == 0 || dur <= 0) 0 else Math.abs(cd - dur)
            if (diff < bdiff) { bdiff = diff; bi = i; bdur = cd }
        }
        if (bdiff > 6) return null
        val o = cands.getJSONObject(bi)
        val d = get("https://lyrics.kugou.com/download?ver=1&client=pc&id=${o.getString("id")}&accesskey=${o.getString("accesskey")}&fmt=lrc&charset=utf8") ?: return null
        val content = JSONObject(d).optString("content", "")
        if (content.isEmpty()) return null
        val lrc = String(Base64.decode(content, Base64.DEFAULT), Charsets.UTF_8).replace("\uFEFF", "")
        if (lrc.isBlank()) return null
        return R("KuGou", lrc, stamp.containsMatchIn(lrc), bdur)
    }

    private fun res(id: Long, r: R?): JSONObject =
        JSONObject().put("id", id).put("src", r?.src ?: "").put("synced", r?.synced ?: false)
            .put("lrc", r?.lrc ?: "").put("ldur", r?.ldur ?: 0)

    fun fetch(ctx: Context, id: Long, title: String, artist: String, album: String, dur: Int,
              order: String, force: Boolean, cb: (String) -> Unit) {
        ex.execute {
            val dir = File(ctx.filesDir, "lyrics")
            dir.mkdirs()
            val f = File(dir, "$id.json")
            if (!force && f.exists()) {
                try { cb(f.readText()); return@execute } catch (e: Exception) {}
            }
            if (force) synchronized(miss) { miss.remove(id) }
            val skip = synchronized(miss) { miss.contains(id) }
            if (order.isBlank() || skip) { cb(res(id, null).toString()); return@execute }
            var plain: R? = null
            var hit: R? = null
            for (s in order.split(",")) {
                val r: R? = try {
                    when (s) {
                        "lrclib" -> lrclib(title, artist, album, dur)
                        "netease" -> netease(title, artist, dur)
                        "kugou" -> kugou(title, artist, dur)
                        else -> null
                    }
                } catch (e: Exception) { null }
                if (r == null) continue
                if (r.synced) { hit = r; break }
                if (plain == null) plain = r
            }
            val fin = hit ?: plain
            val j = res(id, fin).toString()
            if (fin != null) {
                try { f.writeText(j) } catch (e: Exception) {}
            } else synchronized(miss) { miss.add(id) }
            cb(j)
        }
    }

    fun clear(ctx: Context) {
        try { File(ctx.filesDir, "lyrics").listFiles()?.forEach { it.delete() } } catch (e: Exception) {}
        synchronized(miss) { miss.clear() }
    }
}
