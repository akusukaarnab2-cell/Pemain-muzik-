plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
val ver = (project.findProperty("appVersion") as String?) ?: "1.0.0"
val bld = ((project.findProperty("buildNumber") as String?) ?: "1").toInt()
val vp = ver.split(".").map { it.toInt() }
android {
    namespace = "com.muzik.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.muzik.app"
        minSdk = 24
        targetSdk = 34
        // versionCode sentiasa naik: besar*1000000 + kecil*10000 + tampalan*1000 + bina (bina < 1000)
        versionCode = vp[0] * 1000000 + vp.getOrElse(1) { 0 } * 10000 + vp.getOrElse(2) { 0 } * 1000 + bld
        versionName = ver
    }
    signingConfigs {
        create("muzik") {
            storeFile = file("muzik.keystore")
            storePassword = "muzik123"
            keyAlias = "muzik"
            keyPassword = "muzik123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("muzik") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
